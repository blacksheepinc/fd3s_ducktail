const char* host = "CTMrotary";
const char* ssid = "CTMrotaryAP";
const char* password = "01234567";

String processor(const String& var) {
  Serial.println(var);
  if (var == "SDKVER") {
    return ESP.getSdkVersion();
  } else if (var == "CPUFREQ") {
    return String(ESP.getCpuFreqMHz());
  } else if (var == "MAC") {
    return WiFi.macAddress();
  } else if (var == "COREVER") {
    return ESP.getCoreVersion();
  } else if (var == "SERIALNO") {
    return String(SERIALNO);
  } else if (var == "VERNO") {
    return String(VERSION_NO);
  } else if (var == "FLASHHEAPSIZE") {
    return String(ESP.getFreeHeap());
  } else if (var == "STORAGEINFO") {
    FSInfo fs_info;
    SPIFFS.info(fs_info);
    float fileTotalKB = (float)fs_info.totalBytes / 1024.0;
    float fileUsedKB = (float)fs_info.usedBytes / 1024.0;
    return String(fileUsedKB) + "/" + String(fileTotalKB);
  } else if (var == "FLASHSCHIPSIZE") {
    return String((float)ESP.getFlashChipSize() / 1024.0 / 1024.0);
  } else if (var == "BOOTVER") {
    return String(ESP.getBootVersion());
  } else if (var == "STORAGEPERCENT") {
    FSInfo fs_info;
    SPIFFS.info(fs_info);
    float fileTotalKB = (float)fs_info.totalBytes / 1024.0;
    float fileUsedKB = (float)fs_info.usedBytes / 1024.0;
    return String(int((fileUsedKB / fileTotalKB) * 100));
  }






  return String();
}

String getContentType( String filename )
{
  if ( filename.endsWith( ".svg"  ) )    return "image/svg+xml";
  else if ( filename.endsWith( ".htm"  ) ) return "text/html";
  else if ( filename.endsWith( ".html" ) ) return "text/html";
  else if ( filename.endsWith( ".css"  ) ) return "text/css";
  else if ( filename.endsWith( ".js"   ) ) return "application/javascript";
  else if ( filename.endsWith( ".png"  ) ) return "image/png";
  else if ( filename.endsWith( ".gif"  ) ) return "image/gif";
  else if ( filename.endsWith( ".jpg"  ) ) return "image/jpeg";
  else if ( filename.endsWith( ".ico"  ) ) return "image/x-icon";
  else if ( filename.endsWith( ".xml"  ) ) return "text/xml";
  else if ( filename.endsWith( ".pdf"  ) ) return "application/x-pdf";
  else if ( filename.endsWith( ".zip"  ) ) return "application/x-zip";
  else if ( filename.endsWith( ".gz"   ) ) return "application/x-gzip";
  else if ( filename.endsWith( ".ini"  ) ) return "text/plain";
  else return "text/plain";
}

bool handleFileRead(String path)
{
  if ( path.endsWith( "/" ) ) path += "index.html";
  String contentType = getContentType( path );
  String pathWithGz = path + ".gz";
  if ( SPIFFS.exists( pathWithGz ) || SPIFFS.exists( path ) )
  {
    if ( SPIFFS.exists( pathWithGz ) ) {
      path += ".gz";
    };
    //    File file = SPIFFS.open( path, "r" );
    //    size_t sent = server.streamFile(file, contentType);
    //    file.close();
    //request->send(SPIFFS, path , contentType);
    return true;
  }
  Serial.print( "NOTFOUND! handleFileRead: " + path );
  Serial.println( " & contentType: " + contentType );
  return false;
}

void onEvent(AsyncWebSocket * server, AsyncWebSocketClient * client, AwsEventType type, void * arg, uint8_t *data, size_t len) {
  if (type == WS_EVT_CONNECT) {
    //client connected
    os_printf("ws[%s][%u] connect\n", server->url(), client->id());
    client->printf("Hello Client %u :)", client->id());
    client->ping();
  } else if (type == WS_EVT_DISCONNECT) {
    //client disconnected
    os_printf("ws[%s][%u] disconnect: %u\n", server->url(), client->id());
  } else if (type == WS_EVT_ERROR) {
    //error was received from the other end
    os_printf("ws[%s][%u] error(%u): %s\n", server->url(), client->id(), *((uint16_t*)arg), (char*)data);
  } else if (type == WS_EVT_PONG) {
    //pong message was received (in response to a ping request maybe)
    os_printf("ws[%s][%u] pong[%u]: %s\n", server->url(), client->id(), len, (len) ? (char*)data : "");
  } else if (type == WS_EVT_DATA) {
    //data packet
    AwsFrameInfo * info = (AwsFrameInfo*)arg;
    if (info->final && info->index == 0 && info->len == len) {
      //the whole message is in a single frame and we got all of it's data
      os_printf("ws[%s][%u] %s-message[%llu]: ", server->url(), client->id(), (info->opcode == WS_TEXT) ? "text" : "binary", info->len);
      if (info->opcode == WS_TEXT) {
        data[len] = 0;
        os_printf("%s\n", (char*)data);
      } else {
        for (size_t i = 0; i < info->len; i++) {
          os_printf("%02x ", data[i]);
        }
        os_printf("\n");
      }
      if (info->opcode == WS_TEXT)
        client->text("I got your text message");
      else
        client->binary("I got your binary message");
    } else {
      //message is comprised of multiple frames or the frame is split into multiple packets
      if (info->index == 0) {
        if (info->num == 0)
          os_printf("ws[%s][%u] %s-message start\n", server->url(), client->id(), (info->message_opcode == WS_TEXT) ? "text" : "binary");
        os_printf("ws[%s][%u] frame[%u] start[%llu]\n", server->url(), client->id(), info->num, info->len);
      }

      os_printf("ws[%s][%u] frame[%u] %s[%llu - %llu]: ", server->url(), client->id(), info->num, (info->message_opcode == WS_TEXT) ? "text" : "binary", info->index, info->index + len);
      if (info->message_opcode == WS_TEXT) {
        data[len] = 0;
        os_printf("%s\n", (char*)data);
      } else {
        for (size_t i = 0; i < len; i++) {
          os_printf("%02x ", data[i]);
        }
        os_printf("\n");
      }

      if ((info->index + len) == info->len) {
        os_printf("ws[%s][%u] frame[%u] end[%llu]\n", server->url(), client->id(), info->num, info->len);
        if (info->final) {
          os_printf("ws[%s][%u] %s-message end\n", server->url(), client->id(), (info->message_opcode == WS_TEXT) ? "text" : "binary");
          if (info->message_opcode == WS_TEXT)
            client->text("I got your text message");
          else
            client->binary("I got your binary message");
        }
      }
    }
  }
}

void serverHandle(void) {
  Serial.print("Configuring access point...");
  /* You can remove the password parameter if you want the AP to be open. */
  WiFi.softAP(ssid, password);

  if (!SPIFFS.begin()) {
    Serial.println("Failed to mount file system");
    return;
  }

  // attach AsyncWebSocket
  ws.onEvent(onEvent);
  server.addHandler(&ws);

  // attach AsyncEventSource
  server.addHandler(&events);

  //UNIVERSAL FILE SERVE HANDLER
  //  server.onNotFound([](AsyncWebServerRequest * request) {
  //    String path = request->url();
  //    String contentType;
  //    if ( path.endsWith( "/" ) ) path += "index.html";
  //    String pathWithGz = path + ".gz";
  //    if ( SPIFFS.exists( pathWithGz ) || SPIFFS.exists( path ) ) {
  //      if ( SPIFFS.exists( pathWithGz ) ) {
  //        contentType = getContentType( pathWithGz );
  //        request->send(SPIFFS, pathWithGz , contentType);
  //      } else {
  //        contentType = getContentType( path );
  //        request->send(SPIFFS, path , contentType);
  //      };
  //
  //    } else {
  //      Serial.print( "NOTFOUND! handleFileRead: " + path );
  //      Serial.println( " & contentType: " + contentType );
  //      request->send(404);
  //    };
  //
  //  });

  server.onNotFound([](AsyncWebServerRequest * request) {
    String path = request->url();
    Serial.print(path);
    Serial.println(" was sent by onNotFound");
    request->send(SPIFFS, path , getContentType( path ));

  });

  //  server.on("", HTTP_GET, [](AsyncWebServerRequest * request) {
  //    String path = request->url();
  //    String contentType = getContentType( path );
  //    if (path == "/" || path == "/index.html") {
  //      request->send(SPIFFS, path , contentType, false, processor);
  //    } else if (path == "/product.html") {
  //      request->send(SPIFFS, path , contentType, false, processor);
  //    } else if (path == "/restart") {
  //      Serial.println("reboot!");
  //    }
  //    if (SPIFFS.exists( path ) ) {
  //      request->send(SPIFFS, path , contentType);
  //    } else {
  //      Serial.print( "NOTFOUND! handleFileRead: " + path );
  //      Serial.println( " & contentType: " + contentType );
  //      //request->send(404);
  //    };
  //  });

  server.on("/", HTTP_GET, [](AsyncWebServerRequest * request) {
    //    int paramsNr = request->params();
    //    Serial.println(paramsNr);
    //
    //    for(int i=0;i<paramsNr;i++){
    //
    //        AsyncWebParameter* p = request->getParam(i);
    //        Serial.print("Param name: ");
    //        Serial.println(p->name());
    //        Serial.print("Param value: ");
    //        Serial.println(p->value());
    //        Serial.println("------");
    //    }
    request->send(SPIFFS, "/index.html", String(), false, processor);
  });

  server.on("/index.html", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(SPIFFS, "/index.html", String(), false, processor);
  });

  server.on("/product.html", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(SPIFFS, "/product.html", String(), false, processor);
  });

  server.on("/setup.html", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(SPIFFS, "/setup.html", String(), false, processor);
  });

  server.on("/restart", HTTP_GET, [](AsyncWebServerRequest * request) {

    Serial.println("reboot");
    request->redirect("/");
  });

  // Cache responses for 10 minutes (600 seconds)
  server.serveStatic("/", SPIFFS, "/").setCacheControl("max-age=600");

  server.begin();
  if (!MDNS.begin(host)) {
    Serial.println("Error setting up MDNS responder!");
    while (1) {
      delay(1000);
    }
  }
  MDNS.addService("http", "tcp", 80);
  Serial.printf("Ready! Open http://%s.local in your browser\n", host);

};
