boolean firstContact = false;        // Whether we've heard from the microcontroller
unsigned int currentPressure = 0;
unsigned int sensorStatus = 0;
unsigned int rpm = 0;

unsigned int taskStatusStream;

//char inputString = "";         // a String to hold incoming data
bool stringComplete;
byte inputArray[4];

bool indexStream(void *) {
  static char temp[30];
  sprintf(temp, "%u,%u", sensorStatus, currentPressure);
  events.send(temp, "sensorStatus"); //send event
  return true;
}

bool connectionTest(void *) {
  Serial.println('A');
  return !firstContact;
}

void serialHandle() {
  if (stringComplete) {
    sensorStatus = inputArray[0];
    currentPressure = word(inputArray[1],inputArray[2]);
    rpm = inputArray[3];
//    Serial.print(sensorStatus);
//    Serial.print(";");
//    Serial.print(currentPressure);
//    Serial.print(";");
//    Serial.println(rpm);

//Serial.print("be:");
//Serial.println(inputArray[0],HEX);
//Serial.println(inputArray[1],HEX);
//Serial.println(inputArray[2],HEX);
//Serial.println(inputArray[3],HEX);
    stringComplete = false;
  }
}

int pos = 0;
void serialEvent() {
  while (Serial.available()) {
    // get the new byte:
    byte inByte = Serial.read();
    if (!firstContact && inByte == 'B') {
      firstContact = true;
      Serial.print("done");
    }
    if ((char)inByte == '\n') {
      stringComplete = true;
      //Serial.println("kesz");
      pos = 0;
    } else {
      inputArray[pos] = inByte;
      //Serial.print(inByte,HEX);
      pos++;
    }
  }
}
